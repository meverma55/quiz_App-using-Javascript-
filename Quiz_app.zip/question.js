// creating an array and passing the number , question , options , and answers //
let questions = [
    {
        numb:1,
        question :"which of the following attributes is used to add link to any element?",
        answer : "href",
        options:[
            "link",
            "href",
            "ref",
            "newref",
        ]
    },
    {
        numb:2,
        question :"what does HTML stand for ?",
        answer : "Hyper Text Markup languages",
        options:[
            "Hyper Text Markup languages",
           "Hyper Text Preprocesser",
           "Hyper Text Multiple languages",
           "hyper Tool Maulti languages",
        ]
    },
    {
        numb:3,
        question :"what does PHP stand for?",
        answer : "HyperText Preprocesser",
        options:[
            "HyperText Preprocesser",
            "HyperText Programming",
            "HyperText preprogramming",
            "HyperText processer",
        ]
    },
    {
        numb:4,
        question :"what does CSS stand for?",
        answer : "Cascading Style sheet",
        options:[
            "Colourful Style sheet",
            "Common Style sheet",
            "Computer Style sheet",
            "Cascading Style sheet",
        ]
    },
    {
        numb:5,
        question :"which of the following is true about javascript?",
        answer : "All of above",
        options:[
            "javaScript variable names muststart with a letter or the underscore chractors",
            "javaScrit variable names case sensitive ",
            "javaScript is object-oriented programming language",
            "All of above",
        ]
    },

]